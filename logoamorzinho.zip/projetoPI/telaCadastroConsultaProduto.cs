﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoPI
{
    public partial class telaCadastroConsultaProduto : Form
    {
        private telaInicial telaInicial;
        public telaCadastroConsultaProduto(telaInicial telaInicial)
        {
            InitializeComponent();
            this.telaInicial = telaInicial;
        }

        private void buttonCadastrarProduto_Click(object sender, EventArgs e)
        {
            telaCadastroProduto p = new telaCadastroProduto(this);
            p.Show();
            this.Visible = false; 
        }

        private void buttonVoltarMenu_Click(object sender, EventArgs e)
        {
            this.telaInicial.Show();
            this.Close();
        }

        private void buttonConsultarProduto_Click(object sender, EventArgs e)
        {
            telaConsultarProduto c = new telaConsultarProduto(this);
            c.Show();
            this.Visible = false;
        }
    }
}
