﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoPI
{
    public partial class telaConsultarCadastrarUsuário : Form
    {
        

       

        public telaConsultarCadastrarUsuário()
        {
            InitializeComponent();
            
        }

        private void buttonCadastrarUser_Click(object sender, EventArgs e)
        {

        }

        private void buttonConsultarUser_Click(object sender, EventArgs e)
        {

        }

        private void buttonVoltarMenu_Click(object sender, EventArgs e)
        {

        }
    }
}
