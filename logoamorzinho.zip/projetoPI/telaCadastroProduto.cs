﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoPI
{
    public partial class telaCadastroProduto : Form
    {
       private telaCadastroConsultaProduto cadastroConsultaProduto;
       private telaInicial inicio;
        public telaCadastroProduto(telaCadastroConsultaProduto cadastroConsultaProduto)
        {
            InitializeComponent();
            this.cadastroConsultaProduto = cadastroConsultaProduto;
            
            
        }

        public telaCadastroProduto(telaInicial inicio)
        {
            this.inicio = inicio;
        }

        private void TelaCadastroProduto_Load(object sender, EventArgs e)
        {

        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {

            this.cadastroConsultaProduto.Show();
            this.Close();
        }
    }
}
