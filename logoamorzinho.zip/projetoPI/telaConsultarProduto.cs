﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoPI
{
    public partial class telaConsultarProduto : Form
    {
        private telaCadastroConsultaProduto consultaProduto;
        public telaConsultarProduto(telaCadastroConsultaProduto consultaProduto)
        {
            InitializeComponent();
            this.consultaProduto = consultaProduto;
        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
            this.consultaProduto.Show();
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
