﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetoPI.classes
{
    public class Pedido
    {
        private string cliente;
        private double quantidade;
        private string maquina;

        public Pedido(string cliente, double quantidade, string maquina)
        {
            Cliente = cliente;
            Quantidade = quantidade;
            Maquina = maquina;
        }

        public string Cliente { get => cliente; set => cliente = value; }
        public double Quantidade { get => quantidade; set => quantidade = value; }
        public string Maquina { get => maquina; set => maquina = value; }

        public bool FazerPedido()
        {
            return true;
        }

        public void Alterar()
        {

        }
        public void Excluir()
        {

        }
        public void Consultar()
        {

        }
    }
}
