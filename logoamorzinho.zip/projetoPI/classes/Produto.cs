﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projetoPI.classes
{
    public class Produto
    {
        private int codigo_produto;
        private string descricao;
        private string operacao;

        public Produto(int codigo_produto, string descricao, string operacao)
        {
            Codigo_produto = codigo_produto;
            Descricao = descricao;
            Operacao = operacao;
        }

        public int Codigo_produto { get => codigo_produto; set => codigo_produto = value; }
        public string Descricao { get => descricao; set => descricao = value; }
        public string Operacao { get => operacao; set => operacao = value; }

        public bool Cadastrar()
        {
            return true;
        }
        public void Alterar()
        {

        }
        public void Excluir()
        {

        }
        public void Consultar()
        {

        }
        public int GerarCod() 
        {
            
            return Codigo_produto;
        }
    }
}
