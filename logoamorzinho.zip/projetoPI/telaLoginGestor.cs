﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoPI
{
    public partial class telaLoginGestor : Form
    {
        /*private telaInicial telaInicial;
        private telaConsultarCadastrarUsuário telaConsultarCadastrar;
        private telaCadastroUser cadastroUser;*/

        public telaLoginGestor()
        {
            InitializeComponent();

            /*this.telaInicial = telaInicial;
            this.telaConsultarCadastrar = consultarCadastrarUsuário;
            this.cadastroUser = cadastroUser;*/
        }

       

        private void buttonConfirmaLogin_Click(object sender, EventArgs e)
        {
            /*telaConsultarCadastrarUsuário cadastrarUsuário = new telaConsultarCadastrarUsuário();
            cadastrarUsuário.Show();
            this.Visible = false;*/
        }
    }
}
