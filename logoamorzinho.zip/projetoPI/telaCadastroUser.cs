﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace projetoPI
{
    public partial class telaCadastroUser : Form
    {
        /*private telaLoginGestor telaLoginGestor;
        private telaInicial telaInicial;*/
        public telaCadastroUser()
        {
            InitializeComponent();
           /* this.telaLoginGestor = telaLoginGestor;
            this.telaInicial = telaInicial;*/
        }

        private void printPreviewControl5_Click(object sender, EventArgs e)
        {

        }

        private void textNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonCadastrar_Click(object sender, EventArgs e)

        {
            

            if (textNome.Text != String.Empty && textEmail.Text != String.Empty && textId.Text != String.Empty && textRG.Text != String.Empty && dateTimeNascimento.Text != String.Empty && textSenha.Text != String.Empty && textConfirmacaoSenha.Text != String.Empty && TextCpf.Text != String.Empty)
                {
                Usuario p = new Usuario();
                p.Nome = textNome.Text;
                p.Nascimento = DateTime.Parse(dateTimeNascimento.Text);
                p.Rg = textRG.Text;
                p.Id = int.Parse(textId.Text);
                p.Senha = textSenha.Text;
                p.Cpf = TextCpf.Text;
                p.Email = textEmail.Text;
                p.Confirmasenha = textConfirmacaoSenha.Text;


                if (p.Senha != p.Confirmasenha)
                {
                    MessageBox.Show("Senhas Diferentes");
                    LimpaSenha();

                }
                else
                {
                    if (p.Cadastrar() == true)
                    {
                        MessageBox.Show("Cadastro realizado com sucesso!");
                        LimparCampos();
                       // this.telaInicial.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Preencha todos os campos!");
                    }
                }
            }

            
        }
        public void LimpaSenha()
        {
            textConfirmacaoSenha.Clear();
            textSenha.Clear();
        }
        public void LimparCampos()
        {
            textNome.Clear();
            textId.Clear();
            textEmail.Clear();
            textRG.Clear();
            textSenha.Clear();
            textConfirmacaoSenha.Clear();
            TextCpf.Clear();
            
        }


        public void TextCpf_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void buttonVoltar_Click(object sender, EventArgs e)
        {
           /* this.telaInicial.Show();
            this.Close();*/
        }

        private void telaCadastroUser_Load(object sender, EventArgs e)
        {

        }
    }
}
