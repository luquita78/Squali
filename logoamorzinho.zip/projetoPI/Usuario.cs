﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace projetoPI
{
    public class Usuario
    {
        private int id;
        private string nome;
        private DateTime nascimento;
        private string email;
        private string cpf;
        private string rg;
        private string senha;
        private string confirmasenha;

        public int Id { get => id; set => id = value; }
        public string Nome { get => nome; set => nome = value; }
        public DateTime Nascimento { get => nascimento; set => nascimento = value; }
        public string Email { get => email; set => email = value; }
        public string Cpf { get => cpf; set => cpf = value; }
        public string Rg { get => rg; set => rg = value; }
        public string Senha { get => senha; set => senha = value; }
        public string Confirmasenha { get => confirmasenha; set => confirmasenha = value; }

        #region "ENCAPSULAMENTO";
        /*
        public int getID() 
        {
            return id;
        }
        public void setID(int value) 
        {
            id = value;
            
        }
        public DateTime getNascimento() 
        {
            return nascimento;
        }
        public void setNascimento(DateTime value) 
        {
            nascimento = value;
        }
        public string getCPF()
        {
            return this.cpf;
        }
        public void setCPF(string value)
        {
            cpf = value;
        }
        public string getRG()
        {
            return rg;
        }
        public void setRG(string value)
        {
            rg = value;
        }
        public string getSenha()
        {
            return senha;
        }
        public void setSenha(string value)
        {
            senha = value;

        }
        public string getConfirmacaoSenha()
        {
            return _confirmasenha;
        }
        */
        #endregion


       
        public bool Cadastrar()
        {
            return true;
        }
        public void Alterar()
        {

        }
        public void Excluir()
        {

        }
        public void Consultar()
        {

        }

      

    } 
}
